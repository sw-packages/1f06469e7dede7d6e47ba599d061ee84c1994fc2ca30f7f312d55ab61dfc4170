if(CMAKE_CXX_COMPILER_FRONTEND_VARIANT STREQUAL "MSVC" OR
    CMAKE_CXX_STANDARD_LIBRARY STREQUAL "msvc" OR
    CMAKE_CXX_COMPILER_TARGET MATCHES "(^|-)windows-msvc($|-)")
  include(Compiler/MSVC-CXX-CXXImportStd)
  return()
endif()

function (_cmake_cxx_find_modules_json)
  set(_clang_version "${CMAKE_CXX_COMPILER_VERSION}")
  if(CMAKE_CXX_COMPILER_ID STREQUAL "DPClang")
    set(_clang_version "${CMAKE_CXX_COMPILER_VERSION_INTERNAL}")
  endif()
  if (_clang_version VERSION_LESS "18.1.2" AND
      CMAKE_CXX_STANDARD_LIBRARY STREQUAL "libc++")
    # The original PR had a key spelling mismatch internally. Do not support it
    # and instead require a release known to have the fix.
    # https://github.com/llvm/llvm-project/pull/83036
    set(CMAKE_CXX_COMPILER_IMPORT_STD_ERROR_MESSAGE "LLVM 18.1.2 is required for 'import std' json format fix" PARENT_SCOPE)
    return ()
  endif ()

  if (NOT CMAKE_CXX_STDLIB_MODULES_JSON)
    if (CMAKE_CXX_STANDARD_LIBRARY STREQUAL "libc++")
      set(_clang_modules_json_impl "libc++")
    elseif (CMAKE_CXX_STANDARD_LIBRARY STREQUAL "libstdc++")
      set(_clang_modules_json_impl "libstdc++")
    else ()
      set(CMAKE_CXX_COMPILER_IMPORT_STD_ERROR_MESSAGE "Only `libc++` and `libstdc++` are supported" PARENT_SCOPE)
      return ()
    endif ()

    execute_process(
      COMMAND
        "${CMAKE_CXX_COMPILER}"
        ${CMAKE_CXX_COMPILER_ID_ARG1}
        "-print-file-name=${_clang_modules_json_impl}.modules.json"
      OUTPUT_VARIABLE _clang_libcxx_modules_json_file
      ERROR_VARIABLE _clang_libcxx_modules_json_file_err
      RESULT_VARIABLE _clang_libcxx_modules_json_file_res
      OUTPUT_STRIP_TRAILING_WHITESPACE
      ERROR_STRIP_TRAILING_WHITESPACE)
    if (_clang_libcxx_modules_json_file_res OR
        NOT EXISTS "${_clang_libcxx_modules_json_file}")
      set(CMAKE_CXX_COMPILER_IMPORT_STD_ERROR_MESSAGE "Could not find `${_clang_modules_json_impl}.modules.json` resource" PARENT_SCOPE)
      return ()
    endif ()
    cmake_path(CONVERT "${_clang_libcxx_modules_json_file}" TO_CMAKE_PATH_LIST CMAKE_CXX_STDLIB_MODULES_JSON NORMALIZE)
    set(CMAKE_CXX_STDLIB_MODULES_JSON "${CMAKE_CXX_STDLIB_MODULES_JSON}" PARENT_SCOPE)
  endif ()
endfunction ()
